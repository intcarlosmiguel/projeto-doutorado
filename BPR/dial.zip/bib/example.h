#pragma once

#include "igraph.h"
#include <network.h>
#include <calc.h>
#include <BPR.h>


